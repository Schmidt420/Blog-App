# flutter_blog

A New Flutter Blog Application.


![Screenshot_20200917-145540 1](https://user-images.githubusercontent.com/39396765/93456836-a958c880-f8f7-11ea-8f40-7a0551857020.jpg)

![Screenshot_20200917-145620 1](https://user-images.githubusercontent.com/39396765/93456860-aeb61300-f8f7-11ea-9b9c-fb776c37f437.jpg)

![Screenshot_20200917-145627 1](https://user-images.githubusercontent.com/39396765/93456885-b5dd2100-f8f7-11ea-90d2-c5aede3482b1.jpg)



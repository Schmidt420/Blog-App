
class Blogs {

  String image, title, desc;

  Blogs({this.image, this.title, this.desc});
}